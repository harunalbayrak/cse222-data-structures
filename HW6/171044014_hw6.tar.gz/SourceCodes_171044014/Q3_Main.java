/**
 * The type Q 3 main.
 */
public class Q3_Main {
    /**
     * Main.
     *
     * @param args the args
     */
    public static void main(String[] args){
        testMethods();
    }

    /**
     * Test methods.
     */
    public static void testMethods(){
        LibraryAutomationSystem system = new LibraryAutomationSystem();
        system.menu();
    }
}
