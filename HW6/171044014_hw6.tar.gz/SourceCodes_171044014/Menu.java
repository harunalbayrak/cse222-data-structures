/**
 * The Menu interface.
 */
public interface Menu {
    /**
     * Print.
     *
     * @param system the system
     * @return the int
     */
    int print(LibraryAutomationSystem system);
}
